from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('leafletclimatemap.html')

@app.route('/climate_info_dashboard')
def climate_info_dashboard():
    return render_template('climate_info_dashboard.html')

@app.route('/continent_list_page')
def country_list_page():
    return render_template('continent_list.html')

@app.route('/continent/Africa')
def africa_page():
    return render_template('Africa.html')

@app.route('/continent/Asia')
def asia_page():
    return render_template('Asia.html')

@app.route('/continent/Europe')
def europe_page():
    return render_template('Europe.html')

@app.route('/continent/North America')
def north_america_page():
    return render_template('North_America.html')

@app.route('/continent/Oceania')
def oceania_page():
    return render_template('Oceania.html')

@app.route('/continent/South America')
def south_america_page():
    return render_template('South_America.html')

@app.route('/continent/International Climate Interactions')
def international_climate_interactions_page():
    return render_template('International_Climate_Interactions.html')
# Since you're using PNGs, the /data/<filename> route is not needed for serving JSON anymore.
# However, keep it if you have other use cases.

if __name__ == '__main__':
    app.run(debug=True)
