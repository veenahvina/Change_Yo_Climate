// Creating our initial map object with the desired configurations:
let map = L.map("map", {
    center: [20, 0],
    zoom: 2,
    minZoom: 2,
    maxZoom: 3,
    zoomControl: false
});

// Disable mouse/touch interactions for zooming
map.touchZoom.disable();
map.doubleClickZoom.disable();

// Default style
function defaultStyle(feature) {
    return {
        color: 'black',
        weight: 2,
        fillOpacity: 0.3,
        fillColor: '#EFEFEF'
    };
}

// Style when a country/continent is highlighted
function highlightStyle(feature) {
    return {
        weight: 5,
        color: '#D43F00',
        fillOpacity: 0.7,
        fillColor: '#FCBA03'
    };
}

const DEFAULT_STYLE = {
    color: 'black',
    weight: 2,
    fillOpacity: 0.3,
    fillColor: '#EFEFEF'
};

const HIGHLIGHT_STYLE = {
    weight: 5,
    color: '#D43F00',
    fillOpacity: 0.7,
    fillColor: '#FCBA03'
};

// Function to handle feature interactions
function onEachFeature(feature, layer) {
    // Binding a popup with the country's name
    if (feature.properties && feature.properties.CONTINENT) {
        layer.bindPopup(feature.properties.CONTINENT);
    }
    
    // Click event logic
    layer.on({
        click: function(e) {
            // Check if the current style matches the highlighted style
            const currentStyle = e.target.options;
            if (currentStyle.weight === HIGHLIGHT_STYLE.weight &&
                currentStyle.color === HIGHLIGHT_STYLE.color &&
                currentStyle.fillOpacity === HIGHLIGHT_STYLE.fillOpacity &&
                currentStyle.fillColor === HIGHLIGHT_STYLE.fillColor) {
                e.target.setStyle(DEFAULT_STYLE);  // Unhighlight clicked country/continent
            } else {
                e.target.setStyle(HIGHLIGHT_STYLE);  // Highlight clicked country/continent
            }
            const countryInfoDiv = document.getElementById('country-info');
            countryInfoDiv.innerHTML = `<h4>${feature.properties.CONTINENT}</h4>`;
        }
    });
}

// Fetch the GeoJSON file and then add to the map
fetch('/static/World_Continents.geojson')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        L.geoJSON(data, {
            style: defaultStyle,
            onEachFeature: onEachFeature
        }).addTo(map);
    })
    .catch(error => {
        console.log('There was a problem with the fetch operation:', error.message);
    });

// Define the geographical bounds the map will be restricted to
let southWest = L.latLng(-90, -180);
let northEast = L.latLng(90, 180);
let bounds = L.latLngBounds(southWest, northEast);

// Set the max bounds
map.setMaxBounds(bounds);

